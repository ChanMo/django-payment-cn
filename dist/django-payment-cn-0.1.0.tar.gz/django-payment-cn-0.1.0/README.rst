==============
DjangoPayment
==============

基于Django的支付模块

Quick start
-------------

1. Add "payment" to your INSTALLED_APPS setting
   like this::

    INSTALLED_APPS = [
        ...
        'payment'
    ]

 2. Run `python manage.py migrate` to create the payment models.
